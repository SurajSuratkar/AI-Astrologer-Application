﻿# -*- coding: utf-8 -*-
import streamlit as st
from datetime import datetime

st.set_page_config(page_title="AI Astrologer", page_icon="✨", layout="centered")

st.title("🔮 AI Astrologer")
st.write("Enter your birth details and ask the stars about your future!")

# ---------------- Collect User Input ----------------
with st.form("astro_form"):
    name = st.text_input("Your Name")
    dob = st.date_input("Date of Birth")
    tob = st.time_input("Time of Birth")
    pob = st.text_input("Place of Birth")

    user_question = st.text_input("Ask a Question (e.g., How will my career be?)")
    submit = st.form_submit_button("Get Prediction")

# ---------------- Astrology Logic ----------------
def zodiac_sign(day, month):
    signs = [
        (120, "Capricorn"), (219, "Aquarius"), (320, "Pisces"), (420, "Aries"),
        (521, "Taurus"), (621, "Gemini"), (722, "Cancer"), (822, "Leo"),
        (922, "Virgo"), (1022, "Libra"), (1121, "Scorpio"), (1221, "Sagittarius"),
        (1231, "Capricorn")
    ]
    date_code = month * 100 + day
    for cutoff, sign in signs:
        if date_code <= cutoff:
            return sign
    return "Capricorn"

def generate_horoscope(sign):
    messages = {
        "Aries": "You are bold, energetic, and adventurous. A new opportunity may soon knock on your door.",
        "Taurus": "Steady and reliable, but don’t resist change. A financial gain is on the horizon.",
        "Gemini": "Curious and versatile. This week brings new connections and exciting conversations.",
        "Cancer": "Emotional yet strong. Focus on family and personal growth.",
        "Leo": "Confident and charismatic. Recognition and leadership roles await you.",
        "Virgo": "Practical and detail-oriented. Health and discipline will bring success.",
        "Libra": "Balanced and fair-minded. Relationships may need your attention.",
        "Scorpio": "Passionate and powerful. Transformation is coming—embrace it.",
        "Sagittarius": "Adventurous and optimistic. Travel and exploration are favored.",
        "Capricorn": "Ambitious and disciplined. Hard work will soon pay off.",
        "Aquarius": "Innovative and independent. A surprise collaboration may benefit you.",
        "Pisces": "Compassionate and intuitive. Creativity will flow strongly this month.",
    }
    return messages.get(sign, "The stars are silent...")

def answer_question(question, sign):
    q = question.lower()
    if "career" in q:
        return f"As a {sign}, your career will thrive if you stay focused. Growth opportunities are likely this year."
    elif "love" in q or "relationship" in q:
        return f"The stars indicate new beginnings in your love life. {sign}s should stay open to emotional connections."
    elif "health" in q:
        return f"Health looks steady, but {sign}s should watch their energy levels and balance rest with activity."
    elif "money" in q or "finance" in q:
        return f"Financial stability is improving. A good time for {sign}s to plan investments."
    else:
        return f"As a {sign}, the universe suggests patience. More clarity will come soon."

# ---------------- Display Output ----------------
if submit:
    if name and pob and user_question:
        sign = zodiac_sign(dob.day, dob.month)
        st.subheader(f"🌌 Hello {name}, born under the sign of {sign}!")
        st.write(generate_horoscope(sign))

        st.markdown("---")
        st.subheader("✨ Answer to Your Question:")
        st.write(answer_question(user_question, sign))
    else:
        st.error("⚠️ Please fill in all details and ask a question.")
